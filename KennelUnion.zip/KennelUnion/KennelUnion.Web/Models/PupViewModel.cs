﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KennelUnion.Web.Models
{
    public class PupViewModel
    {
        public string Name { get; set; }
        public string Color { get; set; }
        public string Chip { get; set; }
        public string Sex { get; set; }
    }
}
